Core/Src/eletriciade.o: ../Core/Src/eletriciade.c
