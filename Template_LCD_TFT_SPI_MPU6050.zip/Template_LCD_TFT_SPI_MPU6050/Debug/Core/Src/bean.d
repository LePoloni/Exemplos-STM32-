Core/Src/bean.o: ../Core/Src/bean.c
