Core/Src/red_100x50.o: ../Core/Src/red_100x50.c
