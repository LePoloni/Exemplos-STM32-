Core/Src/blue_100x50.o: ../Core/Src/blue_100x50.c
